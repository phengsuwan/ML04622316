
class Practical1(object): 

    def __init__(self):
        pass

    def q1(self): 
        global a 
        if a == 3: 
            print("\033[92mถูกต้องนะค๊าบบ!\033[0m")
        else: 
            print("\033[91mลองใหม่อีกครั้ง!\033[0m")    

    def test(self):
        print("\033[92mทดสอบ\033[0m")
        

p1 = Practical1()