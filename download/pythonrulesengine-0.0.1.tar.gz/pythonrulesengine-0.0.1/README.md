# pythonRulesEngine

## Generate API document
Install dependencies.
```
pip install pdoc3
```

Exclude modules that do not want to generate in `__init__.py`
```py
__pdoc__ = {
    'compiler': False,
    'collection': False,
    'date': False,
    'lookup': False,
}
```

Generate html document. The document is found in html folder.
```
pdoc --html pyrengine --force --config show_source_code=False --template-dir templates/pdoc3
```

