import json
from pyrengine.objectlist import OBJECTLIST
from typing import Union

REFERENCE_DIR = "./db/lookup"

class LOOKUP:
    cache = {}
    reference_dir = REFERENCE_DIR


    # set_reference_dir is used to set the lookup table base directory 
    @classmethod
    def set_reference_dir(cls, reference_dir=REFERENCE_DIR): 
        cls.reference_dir = reference_dir

    # TODO: Check file format.
    # TODO: Error handling.
    @classmethod
    def load(cls, name: str):
        filename = '{}/{}.json'.format(cls.reference_dir, name)
        print('Loading {}'.format(filename))
        try:
            with open(filename, 'r') as f:
                ref = json.load(f)
                ref = OBJECTLIST(ref)
                cls.cache[name] = ref
                return ref
        except:
                print('file {}'.format(filename) + ' missed')
                return None

    @classmethod
    def get(cls, name: str):
        if name not in cls.cache:
            rt=cls.load(name)
            if rt is None:
                 #return None
                 raise Exception("LOOKUP has no {}".format(name))

        return cls.cache[name]

    # Class subscription
    # https://stackoverflow.com/a/63663183
    # https://stackoverflow.com/questions/73562722/extending-generic-class-getitem-in-python-to-accept-more-params
    @classmethod
    def __class_getitem__(cls, name: str):  # Support LOOKUP[name]  
        return cls.get(name)
        
    @classmethod
    def set(cls, name: str, db: Union[list, OBJECTLIST]):
        if not isinstance(db, OBJECTLIST):
            db = OBJECTLIST(db)
        cls.cache[name]=db
        return True

    @classmethod
    def remove(cls, name: str):
        rf=False
        if name in cls.cache:
            rf=True
            del cls.cache[name]

        return rf

    @classmethod
    def listtable(cls):
        ret=[]
        for r in cls.cache.keys():
            ret.append(r)

        return ret
    
    @classmethod
    def reset(cls):
        cls.cache.clear()

        return True