import fnmatch
from collections import defaultdict
from datetime import datetime

# Return COLLECTION
class FILTERED_BY_VALUE:
    def __init__(self, data):
        self.data = data

    def eq(self, other):
        if not isinstance(other, (int, float)):
            return NotImplemented
        return COLLECTION(list(filter(lambda e: e[1] == other, self.data)))

    def gt(self, other):
        return COLLECTION(list(filter(lambda e: e[1] > other, self.data)))

    def ge(self, other):
        return COLLECTION(list(filter(lambda e: e[1] >= other, self.data)))

    def lt(self, other):
        return COLLECTION(list(filter(lambda e: e[1] < other, self.data)))

    def le(self, other):
        return COLLECTION(list(filter(lambda e: e[1] <= other, self.data)))

    # Cannot use 'in' since it is a reserved word.
    def is_in(self, other):
        return COLLECTION(list(filter(lambda e: e[1] in other, self.data)))

    def __str__(self):
        return 'FILTERED_BY_VALUE' + str(self.data)
    
# Return COLLECTION
class FILTERED_BY_KEY:
    def __init__(self, data):
        self.data = data
        
    def eq(self, other):
        return COLLECTION(list(filter(lambda e: e[0] == other, self.data)))

    def like(self, wildcard):
        return COLLECTION(list(filter(lambda e: fnmatch.fnmatch(e[0], wildcard), self.data)))        

    # Cannot use 'in' since it is a reserved word.
    def is_in(self, other):
        return COLLECTION(list(filter(lambda e: e[0] in other, self.data)))
        
    def __str__(self):
        return 'FILTERED_BY_KEY' + str(self.data)        


# Return True or False
class FOR_ALL_VALUES:
    def __init__(self, data):
        self.data = data

    # return True if all values == other
    def eq(self, other):
        return len(list(filter(lambda e: e[1] != other, self.data))) == 0

    # return True if all values > other
    def gt(self, other):
        return len(list(filter(lambda e: e[1] <= other, self.data))) == 0

    def ge(self, other):
        return len(list(filter(lambda e: e[1] < other, self.data))) == 0

    def lt(self, other):
        return len(list(filter(lambda e: e[1] >= other, self.data))) == 0

    def le(self, other):
        return len(list(filter(lambda e: e[1] > other, self.data))) == 0

    def __str__(self):
        return 'FOR_ALL_VALUES' + str(self.data)

 
# Return True or False
class FOR_ANY_VALUES:
    def __init__(self, data):
        self.data = data

    # return True if there exists value == other
    def eq(self, other):
        return len(list(filter(lambda e: e[1] == other, self.data))) > 0

    # return True if there exists value > other
    def gt(self, other):
        return len(list(filter(lambda e: e[1] > other, self.data))) > 0

    def ge(self, other):
        return len(list(filter(lambda e: e[1] >= other, self.data))) > 0

    def lt(self, other):
        return len(list(filter(lambda e: e[1] < other, self.data))) > 0

    def le(self, other):
        return len(list(filter(lambda e: e[1] <= other, self.data))) > 0

    def __str__(self):
        return 'FOR_ANY_VALUES' + str(self.data)


# Some methods return a primitive. Others return a new COLLECTION 
class COLLECTION: 
    def __init__(self, data):
        self.data = data

    def somemethod(self, *args):
        return self 
        
    ######################
    # Return a primitive #
    ######################
    
    # return int
    def count(self):
        return len(self.data)
    
    # return sum of values
    def sum(self):
        return sum(map(lambda e: e[1], self.data))    

    # return value or 0
    def get(self, key):
        return (list(filter(lambda e: e[0] == key, self.data)) or [(key, 0)])[0][1]
    
    #######################
    # Return a COLLECTION #
    #######################    

    # return COLLECTION 
    def sum_by_key(self):
        d = defaultdict(lambda: 0)
        for k,v in self.data:
            d[k] = d[k] + v  
        return COLLECTION(list(d.items()))

    #####################################
    # Return an intermediate COLLECTION #
    #####################################    
    
    # return FILTERED_BY_KEY
    def filter_by_key(self):
        return FILTERED_BY_KEY(self.data)
    
    # return FILTERED_BY_VALUE
    def filter_by_value(self):
        return FILTERED_BY_VALUE(self.data)

    # return FOR_ALL_VALUES
    def for_all_values(self):
        return FOR_ALL_VALUES(self.data)

    # return FOR_ANY_VALUES
    def for_any_values(self):
        return FOR_ANY_VALUES(self.data)

    def __str__(self):
        return 'COLLECTION' + str(self.data)


